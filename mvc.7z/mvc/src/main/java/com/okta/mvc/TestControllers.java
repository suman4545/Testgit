package com.okta.mvc;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestControllers {

	
	@GetMapping("/getprivate")
	String restricted() {
        return "getprivate";
    }
	
	@GetMapping("/getpublic")
	String getpublic() {
        return "getpublic";
    }
	
}
